﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using MetroFramework.Controls;

namespace TeamProject
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public List<일정Group> groupList = new List<일정Group>();
        public Form1()
        {
            InitializeComponent();
        }

        private void metroButton_Add_Click(object sender, EventArgs e) // 일정 추가 add 버튼 클릭
        {
            if (!String.IsNullOrWhiteSpace(metroTextBox1.Text)) //tasks 간단하게 유지하기 위해 빈 작업을 수락하지 않음
            {

                일정Group group = new 일정Group();
                GroupBox groupBox = new GroupBox();
                TextBox textBox = new TextBox();
                MetroButton editBtn = new MetroButton();
                MetroButton deleteBtn = new MetroButton();
                MetroButton saveBtn = new MetroButton();

                group.GroupBox_일정 = groupBox;
                group.TextBox_일정 = textBox;
                group.EditBtn_일정 = editBtn;
                group.DeleteBtn_일정 = deleteBtn;

                groupBox.Controls.Add(textBox);
                groupBox.Controls.Add(editBtn);
                groupBox.Controls.Add(deleteBtn);

                groupList.Add(group);


                // groupBox 속성 설정
                groupBox.Size = new Size(340, 100);

                // button 속성 설정
                editBtn.Size = new Size(75, 23);
                editBtn.Location = new Point(179, 71);
                editBtn.Text = "Edit";
                editBtn.Click += editBtn_Click;

                deleteBtn.Size = new Size(75, 23);
                deleteBtn.Location = new Point(259, 71);
                deleteBtn.Text = "Delete";
                deleteBtn.Click += deleteBtn_Click;

               //does not work
                saveBtn.Size = new Size(75, 23);
                saveBtn.Location = new Point(99, 71);
                saveBtn.Text = "Save";
               // saveBtn.Visible = true; 
                saveBtn.Click += saveBtn_Click;
               

                // textBox 속성 설정
                textBox.ReadOnly = true;
                textBox.Multiline = true;
                textBox.Size = new Size(328, 47);
                textBox.Location = new Point(6, 20);
                textBox.Text = groupList.Count.ToString() + ". " + metroTextBox1.Text;       

                metroTextBox1.Text = ""; //사용자의 편의를 위해 텍스트를 빈 문자열로 설정
                textBoxAlignment();
            }
        }

        private void textBoxAlignment() // 텍스트 박스 정렬
        {
            while(flowLayoutPanel_일정.Controls.Count > 1) // 기존의 텍스트 박스를 전부 지움
            {
                flowLayoutPanel_일정.Controls.RemoveAt(1);
            }

            for (int i = groupList.Count - 1; i >= 0; i--) // textBoxList의 textBox들을 다시 전부 넣어줌
            {
                flowLayoutPanel_일정.Controls.Add(groupList[i].GroupBox_일정);
                groupList[i].GroupBox_일정.Name = "group" + i.ToString();
                groupList[i].DeleteBtn_일정.Name = "btn" + i.ToString();
            }

            for (int i = 0; i < flowLayoutPanel_일정.Controls.Count; i++)
            {
                Console.WriteLine(flowLayoutPanel_일정.Controls[i].Name);
            }
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            //access the given text box with a double click: readonly->write
            //write 
            //press edit - save the new result
            //readonly again

           
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void deleteBtn_Click(object sender, EventArgs e) 
        {
            MetroButton btn = sender as MetroButton;
            int deleteIndex=-1;
            for (int i = 0; i < groupList.Count; i++)
            {
                if(groupList[i].DeleteBtn_일정.Name == btn.Name)
                {
                    deleteIndex = i;
                    break;
                }
            }

            groupList.RemoveAt(deleteIndex);
            textBoxAlignment();

            //*  We need tasks' number for each task after deletion *//
            //update indices idk how to do it without overwriting HELP!!!!!!!
            for (int i = 0; i < groupList.Count; i++)
            {
                string txtBoxStr = groupList[i].TextBox_일정.Text;
                txtBoxStr = txtBoxStr.Remove(0, 1);
                txtBoxStr = txtBoxStr.Insert(0, (i+1).ToString());
                groupList[i].TextBox_일정.Text = txtBoxStr;
            }    
        }

    
    }

    public class 일정Group // 버튼을 누르면 생성되는 Control들 모음
    {
        private GroupBox groupBox_일정;
        private TextBox textBox_일정;
        private MetroButton editBtn_일정;
        private MetroButton deleteBtn_일정;
        private MetroButton saveBtn_일정;

        // properties
        public GroupBox GroupBox_일정
        {
            get;
            set;
        }

        public TextBox TextBox_일정
        {
            get;
            set;
        }

        public MetroButton EditBtn_일정
        {
            get;
            set;
        }

        public MetroButton DeleteBtn_일정
        {
            get;
            set;
        }

        public MetroButton SaveBtn_일정
        {
            get;
            set;
        }
    }
}
